import React from "react";

// Customizable Area Start
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    Button,
    ScrollView,
    Platform,
    Image,
    TouchableOpacity,
    TouchableWithoutFeedback,
    KeyboardAvoidingView,
    CheckBox
} from "react-native";
import { Formik } from "formik";
import * as Yup from "yup";
import CustomCheckBox from "../../../components/src/CustomCheckBox";
import CustomRadioButton from '../../../components/src/CustomRadioButton.web'
import SocialMedia from '../../social-media-account-registration/src/SocialMediaAccountRegistrationScreen.web';

import CountryCodeSelector from "../../country-code-selector/src/CountryCodeSelector";
// Customizable Area End

import EmailAccountRegistrationController, {
    Props
} from "./EmailAccountRegistrationWebController";


export default class EmailAccountRegistration extends EmailAccountRegistrationController {
    constructor(props: Props) {
        super(props);
        console.log(props);
    };
    render() {
        const options = [
            {
                key: 'student',
                text: 'Student',
            },
            {
                key: 'publisher',
                text: 'Publisher',
            }
        ]
        console.log(this.state.selectedOptions, 'll')
        return (
            <KeyboardAvoidingView
                behavior={this.isPlatformiOS() ? "padding" : undefined}
                style={styles.keyboardPadding}
            >
                <Formik
                    initialValues={{ accountType: "email_account", email: "", password: "", firstName: "" }}
                    validationSchema={Yup.object().shape(this.state.validationSchema)}
                    //    validationSchema={Yup.object().shape(this.state.passwordSchema)}
                    validateOnMount={true}
                    validateOnChange={true}
                    onSubmit={(values, actions) => {
                        //this.goToOtpAfterEmailValidation(values);
                        actions.setSubmitting(false);
                        this.createAccount(values);
                        console.log(values);
                    }}
                >
                    {({
                        handleChange,
                        handleSubmit,
                        errors,
                        setFieldTouched,
                        touched
                    }) => (
                        <View style={styles.registrationContainer}>
                            <ScrollView keyboardShouldPersistTaps="always" style={styles.container}>
                                <TouchableWithoutFeedback
                                    testID={"Background"}
                                    onPress={() => {
                                        this.hideKeyboard();
                                    }}
                                >
                                    {/* Customizable Area Start */}
                                    <View>
                                        <View style={styles.headerContainer}>
                                            <View style={styles.headline}>
                                                {this.isPlatformWeb() ? (
                                                    <Text style={styles.signUpText}>Sign Up</Text>
                                                ) : null}
                                            </View>
                                            {/* <View style={styles.fbbtnContainer}>
                                                <Image source={fbIcon} style={styles.fbIcon} />
                                            </View> */}
                                            <View>
                                                {/* <Image source={googleIcon} testID="btnGoogleLogIn" style={styles.googlicon} /> */}
                                                {/* <CustomGoogleLogInButton
                                                    testID="btnGoogleLogIn" //Merge Engine::From BDS
                                                    style={styles.googleStyle} //UI Engine::From Sketch
                                                    loginGoogleButtonText={configJSON.googleButtonText} //UI Engine::From Sketch
                                                    googleButtonImageStyle={styles.googleButtonImageStyle} //UI Engine::From Sketch
                                                    googleButtonTextStyle={styles.googleButtonTextStyle} //UI Engine::From Sketch
                                                    {...this.btnGoogleLogInProps} //Merge Engine::From BDS - {...this.testIDProps}
                                                /> */}
                                                <SocialMedia id="null" navigation="null" />
                                            </View>
                                        </View>
                                        <Text style={styles.fieldLabel}>Full Name</Text>
                                        <TextInput
                                            testID={"txtInputFirstName"}
                                            style={Platform.OS === "web" ? styles.inputWeb : styles.bgInput}
                                            placeholder={this.labelFirstName}
                                            onBlur={() => setFieldTouched("firstName")}
                                            onChangeText={handleChange("firstName")}
                                        //  errorStyle={{ color: this.firstInputErrorColor }}
                                        //  {...this.txtInputFirstNamePrpos} //Merge Engine::From BDS - {...this.testIDProps}
                                        />
                                        {touched.firstName && errors.firstName ? (
                                            <Text style={styles.validationError}>{errors.firstName}</Text>
                                        ) : null}

                                        <Text style={styles.fieldLabel}>Make your account as</Text>
                                        <View style={styles.radiobtncontainer}>
                                            <CustomRadioButton
                                                selectedOption={this.state.selectedOptions}
                                                onSelect={this.onSelect}
                                                options={options}
                                            />
                                        </View>

                                        <Text style={styles.fieldLabel}>Email Address</Text>
                                        <TextInput
                                            testID={"txtInputEmail"}
                                            style={Platform.OS === "web" ? styles.inputWeb : styles.bgInput}
                                            placeholder={this.labelEmail}
                                            onBlur={() => setFieldTouched("email")}
                                            onChangeText={handleChange("email")}
                                        // {...this.txtInputEmailPrpos} //Merge Engine::From BDS - {...this.testIDProps}
                                        />
                                        {touched.email && errors.email ? (
                                            <Text style={styles.validationError}>{errors.email}</Text>
                                        ) : null}
                                        <Text style={styles.fieldLabel}>Password</Text>

                                        <TextInput
                                            testID={"txtInputPassword"}
                                            secureTextEntry={true}
                                            style={Platform.OS === "web" ? styles.inputWeb : styles.bgInput}
                                            placeholder={this.labelPassword}
                                            //{...this.txtInputPasswordProps}
                                            onBlur={() => setFieldTouched("password")}
                                            onChangeText={handleChange("password")}
                                        />
                                        {touched.password && errors.password ? (
                                            <Text style={styles.validationError}>{errors.password}</Text>
                                        ) : null}
                                        <View style={styles.checkboxContainer}>
                                            <View style={styles.checkbox}>
                                                <CustomCheckBox
                                                    testID={"CustomCheckBox"} //Merge Engine::From BDS
                                                    {...this.CustomCheckBoxProps} //Merge Engine::From BDS - {...this.testIDProps}
                                                />
                                            </View>

                                            <Text style={styles.label}>I agree to the <Text style={styles.policyTxt}>Privacy Policy</Text> for using the app.</Text>
                                        </View>
                                        {/* <Button
                                    testID={"btnSignUp"}
                                    title={this.btnTextSignUp}
                                    color="#3AAEEF"
                                    {...this.btnSignUpProps}
                                /> */}
                                        <View >
                                            <Text testID={"btnSignUp"}
                                                style={styles.continuebbtn}
                                                onPress={() => handleSubmit()}
                                            >
                                                CONTINUE
                            </Text>
                                        </View>
                                        <Text style={styles.signlabel}>Already have an account? <Text {...this.btnLoginProps} style={styles.policyTxt}>Sign in</Text></Text>
                                    </View>

                                    {/* Customizable Area End */}
                                </TouchableWithoutFeedback>
                            </ScrollView>
                        </View>
                    )}
                </Formik>

            </KeyboardAvoidingView>
        );
    }

    async componentDidMount() {
        // Customizable Area Start
        this.getValidations();
        // Customizable Area End
    }
}

const styles = StyleSheet.create({
    // Customizable Area Start
    container: {
        flex: 1,
        padding: 20,
        marginLeft: "auto",
        marginRight: "auto",
        width: Platform.OS === "web" ? "75%" : "100%",
        maxWidth: 650,
        backgroundColor: "#fff",
        marginTop: 50,
        marginBottom: 50,
        borderRadius: 25,
    },
    titleWhySignUp: {
        marginBottom: 32,
        fontSize: 16,
        textAlign: "left",
        marginVertical: 8
    },
    titleOtpInfo: {
        marginBottom: 32,
        fontSize: 16,
        textAlign: "left",
        marginVertical: 8
    },
    bgInput: {
        flexDirection: "row",
        fontSize: 16,
        textAlign: "left",
        backgroundColor: "#00000000",
        marginTop: 24,
        borderWidth: 1,
        borderColor: "#767676",
        borderRadius: 2,
        includeFontPadding: true,
        padding: 10,
    },

    inputWeb: {
        flex: 1,
        flexDirection: "row",
        marginTop: 5,
        fontSize: 18,
        padding: 10,
        borderColor: "#767676",
        includeFontPadding: true,
        outline: "none",
        backgroundColor: "#F8F8F8",
        height: 65,
        borderRadius: 5,
        outlineStyle: "none",
        outlineWidth: 0,
        outlineColor: "transparent"
    },

    bgRectBorder: {
        borderWidth: 1,
        borderColor: "#767676",
        borderRadius: 2,
        marginBottom: 10
    },
    bgPasswordInput: {
        flex: 1,
        fontSize: 16,
        textAlign: "left",
        backgroundColor: "#00000000",
        minHeight: 40,
        includeFontPadding: true,
        marginTop: 10,
        paddingLeft: 0
    },
    passwordShowHide: {
        alignSelf: "center"
    },
    bgPasswordContainer: {
        flexDirection: "row",
        backgroundColor: "#00000000",
        marginBottom: 16,
        borderWidth: Platform.OS === "web" ? 0 : 1,
        borderBottomWidth: 1,
        borderColor: "#767676",
        borderRadius: 2,
        paddingLeft: 5,
        paddingRight: 5,
        zIndex: -1
    },
    imgPasswordShowhide: Platform.OS === "web" ? { height: 30, width: 30 } : {},
    keyboardPadding: { flex: 1 },
    btnLegalTermsAndCondition: { color: "#6200EE" },
    btnLegalPrivacyPolicy: { color: "#6200EE", marginLeft: "auto" },
    leagalText: { marginTop: 10 },
    headline: {
        flex: 1,
        justifyContent: "flex-start",
        alignItems: "flex-start",
        textAlign: "flex-start"
    },
    signUpText: {
        fontSize: 32,
        color: "#11142D",
        fontWeight: "bold",
        fontFamily: "Poppins"
    },
    fieldLabel:
    {
        color: "#B2B3BD",
        marginTop: 20,
        fontSize: 12,
        fontFamily: "Poppins",
        marginBottom: 10
    },
    radioButtonContainer: {
        flex: 0,
        flexDirection: "row",
        alignItems: "center",
        marginRight: 45
    },
    radioButton: {
        height: 20,
        width: 20,
        backgroundColor: "#F8F8F8",
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#E6E6E6",
        alignItems: "center",
        justifyContent: "center"
    },
    radioButtonIcon: {
        height: 14,
        width: 14,
        borderRadius: 7,
        backgroundColor: "#98CFB6"
    },
    radioButtonText: {
        fontSize: 14,
        marginLeft: 16
    },
    checkboxContainer: {
        flexDirection: "row",
        marginBottom: 20,
        marginTop: 20
    },
    checkbox: {
        alignSelf: "center",
    },
    label: {
        margin: 8,
    },
    fbbtnContainer:
    {
        backgroundColor: "#3AAEEF",
        width: 50,
        height: 50,
        borderRadius: 16,
        marginRight: 20,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    googlebtnContainer:
    {
        backgroundColor: "#3AAEEF",
        width: 50,
        height: 50,
        borderRadius: 16,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    googlicon:
    {
        height: 15,
        width: 15,
        flexDirection: 'column',
        alignSelf: "center"
    },
    fbIcon:
    {
        height: 20,
        width: 10,
    },
    headerContainer: {
        flexDirection: "row"
    },
    radiobtncontainer: {
        flexDirection: "row",
    },
    policyTxt:
    {
        color: "#3AAEEF"
    },
    signlabel: {
        marginTop: 20,
        flexDirection: 'column',
        alignSelf: "center"
    },
    continuebbtn: {
        backgroundColor: "#3AAEEF",
        height: 60,
        borderRadius: 10,
        color: "#fff",
        textAlign: "center",
        paddingTop: 20
    },
    registrationContainer:
    {
        width: "100%",
        backgroundColor: "#3AAEEF",
        height: "100%"

    },
    validationError:
    {
        fontSize: 11,
        margin: 5,
        color: "#f55c47"
    }
    // Customizable Area End
});
